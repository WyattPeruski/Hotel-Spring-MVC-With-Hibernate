package co.grandcircus.hotelsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelsearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelsearchApplication.class, args);
	}

}
