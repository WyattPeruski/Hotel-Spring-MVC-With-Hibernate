package co.grandcircus.hotelsearch;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import co.grandcircus.hotelsearch.dao.HotelDao;
import co.grandcircus.hotelsearch.entity.Hotel;

@Controller
public class hotelController {
	@Autowired
	private HotelDao Dao1;
	
	@RequestMapping("/")
public String home() {
		
	
	
	return "Home";
}
	@RequestMapping("/Result")
	public String Result(Model model, @RequestParam("city") String city) {
		List<Hotel> list = Dao1.findByCityOrderByPricePerNightAsc(city);
		model.addAttribute("city", city);
		model.addAttribute("list", list);
		
		return "Result";
	}
}
